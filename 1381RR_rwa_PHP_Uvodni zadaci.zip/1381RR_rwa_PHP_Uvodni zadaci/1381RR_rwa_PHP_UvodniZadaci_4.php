<?php
$i=1;
echo "Parni brojevi od 1 do 100: <br/>";
while($i<=100)
{
  if($i%2==0)
  {
	echo "$i <br/>";
  }
  $i++;
}
?>