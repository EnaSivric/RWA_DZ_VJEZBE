<?php
if(isset($_GET['broj']) && (($_GET['broj']!='')))
{
$broj=$_GET['broj'];
if(isset($_GET['kvadrat'])){
$rez=$broj*$broj;
echo "Poslali ste broj:$broj<br/>Operacija je:KVADRAT<br/>Rezultat je: $rez<br/>";
}
else if(isset($_GET['kub'])){
$rez=$broj*$broj*$broj;
echo "Poslali ste broj:$broj<br/>Operacija je:KUB<br/>Rezultat je: $rez<br/>";
}
else echo "Molim unesite operaciju";
}
else {
echo "Molim unesite broj";
//header('Location: forma.html');
exit;
}
?>