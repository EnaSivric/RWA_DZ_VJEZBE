<?php
$i=100;
echo "Parni troznamenkasti brojevi: <br/>";
while($i<=999)
{
 if($i%2==0)
 {
	echo "$i  ";
 }
 $i++;
}
?>