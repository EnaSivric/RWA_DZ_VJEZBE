<?php
for($i=1; $i<=20; $i++)
{
$kvadrat=$i*$i;
echo "$i kvadrat: $kvadrat <br/>";
}
?>