<?php
$a=9.4;
$b=18.235;
$pov_pravokutnik=$a*$b;
echo "Povrsina pravokutnika sirine $a i duzine $b iznosi $pov_pravokutnik.";  
?>