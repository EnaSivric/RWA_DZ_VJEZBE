<?php
$i=1;
$suma=0;
while($i<=100)
{
$suma+=$i;
$i++;
}
echo "Suma prvih 100 prirodnih brojeva koristenjem while petlje je $suma.";
?>